﻿using System;

namespace _04.DistanceBetweenPoints
{
    public class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
