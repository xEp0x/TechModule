﻿using System;

namespace _05.ClosestTwoPoints
{
    class Point
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
