﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _06.BookLibraryModification
{
    public class Library
    {
        public string Name { get; set; }

        public List<Book> Books { get; set; }
    }
}
